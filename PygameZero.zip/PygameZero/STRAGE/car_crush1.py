
import pgzrun

WIDTH =  800
HEIGHT = 800

car_red = Actor('car_red', center=(200, 300))
car_blue = Actor('car_blue', center=(200, 100))

# 車の接触を表す変数
# 0:接触していない, 1:接触している
status = 0

def draw():
    global status
    screen.clear()
    car_red.draw()
    car_blue.draw()
    if status == 1:
        screen.draw.text('!!CRASH!!',
                         (car_red.x, car_red.y),
                         color = 'yellow', fontsize = 48)  # (7)
        # status = 0

def update():
    global status
    # car_blueの移動
    if keyboard.kp8:
        car_blue.angle = 0
        car_blue.y -= 2
    elif keyboard.kp2:
        car_blue.angle = 180
        car_blue.y += 2
    elif keyboard.kp4:
        car_blue.angle = 90
        car_blue.x -= 2
    elif keyboard.kp6:
        car_blue.angle = -90
        car_blue.x += 2

    # car_redの移動 (WASDキーで操作)
    if keyboard.w:
        car_red.angle = 0
        car_red.y -= 2
    elif keyboard.s:
        car_red.angle = 180
        car_red.y += 2
    elif keyboard.a:
        car_red.angle = 90
        car_red.x -= 2
    elif keyboard.d:
        car_red.angle = -90
        car_red.x += 2

# 2台の車の接触判定
    if car_red.colliderect(car_blue):
        if status == 0:  # 接触していない状態からの変化で効果音を再生
            status = 1
            sounds.crash.play()

    else:

        status = 0  # 車が離れたらstatusを0に戻す


pgzrun.go()

import pgzrun
import time

WIDTH =  600
HEIGHT = 600

car_red = Actor('car_red', center=(200, 300))
car_blue = Actor('car_blue', center=(200, 100))

# スコア変数
score_red = 0
score_blue = 0

# タイマー関連
GAME_TIME = 120  # 2分（秒）
start_time = time.time()
game_over = False

# 車の接触を表す変数
# 0:接触していない, 1:接触している
status = 0

# 最後に動かした側を記録
last_moved = None  # "red" または "blue"

def draw():
    global status, game_over
    screen.clear()
    car_red.draw()
    car_blue.draw()
    # スコアボード
    screen.draw.text(f"Car_Red: {score_red}", (10, 10), color="red", fontsize=40)
    screen.draw.text(f"Car_Blue: {score_blue}", (WIDTH-200, 10), color="blue", fontsize=40)
    # タイマー
    remaining = max(0, GAME_TIME - int(time.time() - start_time))
    min_sec = f"{remaining//60:02}:{remaining%60:02}"
    screen.draw.text(f"Time: {min_sec}", (WIDTH//2-60, 10), color="white", fontsize=40, )
    message = "Don’t try to do this!°ω°"
    screen.draw.text(message, (20, HEIGHT - 40), color="orange", fontsize=32)
    if status == 1:
        screen.draw.text('!!CRASH!!',
                         (car_red.x, car_red.y),
                         color = 'yellow', fontsize = 48)
    if game_over:
        screen.draw.text('GAME SET', (WIDTH//2-100, HEIGHT//2-40), color='orange', fontsize=60)

def update():
    global status, score_red, score_blue, game_over, last_moved
    if game_over:
        return
    moved = False
    # car_blueの移動
    if keyboard.kp8:
        car_blue.angle = 0
        car_blue.y -= 2
        last_moved = "blue"
        moved = True
    elif keyboard.kp2:
        car_blue.angle = 180
        car_blue.y += 2
        last_moved = "blue"
        moved = True
    elif keyboard.kp4:
        car_blue.angle = 90
        car_blue.x -= 2
        last_moved = "blue"
        moved = True
    elif keyboard.kp6:
        car_blue.angle = -90
        car_blue.x += 2
        last_moved = "blue"
        moved = True

    # car_redの移動 (WASDキーで操作)
    if keyboard.w:
        car_red.angle = 0
        car_red.y -= 2
        last_moved = "red"
        moved = True
    elif keyboard.s:
        car_red.angle = 180
        car_red.y += 2
        last_moved = "red"
        moved = True
    elif keyboard.a:
        car_red.angle = 90
        car_red.x -= 2
        last_moved = "red"
        moved = True
    elif keyboard.d:
        car_red.angle = -90
        car_red.x += 2
        last_moved = "red"
        moved = True

    # 2台の車の接触判定
    if car_red.colliderect(car_blue):
        if status == 0:
            status = 1
            if last_moved == "red":
                score_red += 1
            elif last_moved == "blue":
                score_blue += 1
            sounds.crash.play()
    else:
        status = 0

    # タイマー判定
    elapsed = time.time() - start_time
    if elapsed >= GAME_TIME:
        game_over = True


pgzrun.go()
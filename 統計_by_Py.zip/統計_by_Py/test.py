import statistics # 基本的な統計計算を行うためのpythonモジュール
import math       #　数学計算用のpythonのpythonモジュール

data = [45, 55, 55, 55, 65, 65, 70, 70] # ８つの値を格納したリストを、変数dataに代入する

# 0.平均値 mean関数を使う

mean = statistics.mean(data) 

# 1.中央値 median関数を使う
median = statistics.median(data)

# 2.最頻値　mode関数を使う
mode = statistics.mode(data)

# 3.範囲　max関数で求めた範囲内の最大値 ー min関数で求めた範囲内の最小値
_range = max(data) - min(data)

# 4.分散 pvariance関数を使う
variance = statistics.pvariance(data)

# 標準偏差　math.sqrt関数で,分散(variance)の平方根をとる
std_dev = math.sqrt(variance)


print("平均値",mean)
print("中央値:", median)
print("最頻値:", mode)
print("範囲:", _range)
print("分散:", variance)
print("標準偏差:",round(std_dev,2)) #round関数で小数点以下第３位で四捨五入し、第２位までの表示とする









